#!/bin/bash

# Note that this will only build a single java file
javac -cp lib/spigot-1.8.jar -d bin/ htb/dyplesher/plugin/CreateFile.java
cp src/plugin.yml bin/plugin.yml
 
# Make a JAR file
jar -cvf createfile.jar -C bin .
